export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyCKYocm2-KJyV5hzR7-uftchFMWyv19Ruk",
    authDomain: "angularfirebase-sandbox.firebaseapp.com",
    projectId: "angularfirebase-sandbox",
    storageBucket: "angularfirebase-sandbox.appspot.com",
    messagingSenderId: "769012752903",
    appId: "1:769012752903:web:3c2077e64be110d05d40a2",
    measurementId: "G-ESEVRETBDJ"
  }
};

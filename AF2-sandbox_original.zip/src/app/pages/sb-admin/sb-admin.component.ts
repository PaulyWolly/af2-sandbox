import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sb-admin',
  templateUrl: './sb-admin.component.html',
  styleUrls: ['./sb-admin.component.css']
})
export class SbAdminComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myresume',
  templateUrl: './myresume.component.html',
  styleUrls: ['./myresume.component.css']
})
export class MyresumeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
